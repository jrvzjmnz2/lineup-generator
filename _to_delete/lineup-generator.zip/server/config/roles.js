// Central list of marshal roles used throughout the app.
// The first 5 are the roles the "Generate Event" screen sets capacity (+/-) for.
// The remaining 3 are still selectable by marshals and assignable on the
// lineup card, with a default capacity that the employee can adjust on the card.
const ROLES_WITH_EVENT_CAPACITY = ['Operator', 'Spotter', 'Split', 'SLR', 'Head Marshal'];
const ADDITIONAL_ROLES = ['Tech Support', 'Kit Claiming Staff', 'Registration Staff'];
const ALL_ROLES = [...ROLES_WITH_EVENT_CAPACITY, ...ADDITIONAL_ROLES];
const DEFAULT_ADDITIONAL_ROLE_CAPACITY = 2;

module.exports = {
  ROLES_WITH_EVENT_CAPACITY,
  ADDITIONAL_ROLES,
  ALL_ROLES,
  DEFAULT_ADDITIONAL_ROLE_CAPACITY,
};
