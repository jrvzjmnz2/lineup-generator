const mongoose = require('mongoose');

// Stored in DB "lineup", collection "marshal"
// One document per marshal user. Re-submitting the form overwrites this
// document (upsert on userId) so there is never more than one submission.
const marshalSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    username: { type: String, required: true },
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true },
    contactNumber: { type: String, required: true },
    // Events the marshal is willing to join (references Event._id)
    events: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Event' }],
    // Roles the marshal is willing to fill (any of the 8 role names)
    roles: [{ type: String }],
    submittedAt: { type: Date, default: Date.now },
  },
  { timestamps: true, collection: 'marshal' }
);

module.exports = mongoose.model('Marshal', marshalSchema);
